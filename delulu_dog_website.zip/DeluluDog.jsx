import React from 'react'
import './index.css'

// Delulu Dog - Website inspired by Adzilla Meme UI with Google Font (Luckiest Guy)
export default function DeluluDog() {
  return (
    <div style={{ fontFamily: `'Luckiest Guy', cursive` }} className="text-black">
      <header className="w-full bg-white border-b border-black fixed top-0 z-50">
        <div className="max-w-7xl mx-auto flex justify-between items-center px-6 py-4">
          <div className="flex items-center gap-3">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTGu8aUZML3ZYkkiyZqiQdUaelBs13h6rOFSQ&s" alt="Delulu Dog" className="w-10 h-10 rounded-full border border-black" />
            <h1 className="text-2xl font-bold tracking-wide">DELULU DOG</h1>
          </div>
        </div>
      </header>
      <section id="buy" className="bg-yellow-400 min-h-screen flex flex-col items-center justify-center text-center pt-32">
        <h1 className="text-6xl md:text-8xl font-bold mb-4">DELULU DOG</h1>
      </section>
    </div>
  )
}
